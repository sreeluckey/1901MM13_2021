const express = require('express');
const fs = require('fs');

const { spawnSync } = require('child_process');

// express app
const app = express();
if (fs.existsSync('public\\sample_input')) {
  fs.rmSync('public\\sample_input', { recursive: true ,force: true});
}
if (fs.existsSync("marksheets")) {
  fs.rmSync("marksheets", { recursive: true ,force: true});
}
fs.mkdirSync('public\\sample_input');

const multer = require('multer');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public\\sample_input');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage })

const path = require('path')
app.use('/static', express.static(path.join(__dirname, 'public')))

// register view engine
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs');

var positive = -1, negative = 1, flag = 0,flag_r=0;
var message='Upload master_roll.csv,respone.csv and fill +ve,-ve marks then generate roll no. wise marksheet or concise marksheet';

app.get('/', (req, res) => {
  res.render('home', {flag,message,positive, negative,flag_r});
});

const cpUpload = upload.fields([{ name: 'master_roll', maxCount: 1 }, { name: 'response', maxCount: 1 }]);
app.post('/', cpUpload, async (req, res) => {
  console.log("line44")
  positive = req.body.positive;  
  negative = req.body.negative;    
  if (req.body.Roll_Number_wise) {
    const result = spawnSync('python', ['Roll_Number_wise_Marksheet_Generator.py', positive, negative]);
    message = result.stdout.toString();
    console.log(message);
    error = result.stderr.toString();
    console.log(error); 
    flag = 1;
    flag_r=1;
  }
  if (req.body.Concise) {
    const result = spawnSync('python', ['Concise_Marksheet_Generator.py', positive, negative]);
    message = result.stdout.toString();
    console.log(message);
    error = result.stderr.toString();
    console.log(error);
    flag = 1; 
  }
  if (req.body.download) {
     return res.download('./marksheets.zip',); 
  }
  if (req.body.Email) {
    const result = spawnSync('python', ['Send_Email.py']);
    message = result.stdout.toString();
    console.log(message);
    error = result.stderr.toString();
    console.log(error);
  }
  res.redirect('/');
});


// listen for requests
app.listen(3000, () => {
  console.log('Server started on port 3000');
});


    



    