import pandas as pd
import csv,sys,shutil,os
if not os.path.exists(r"public\sample_input\master_roll.csv"): 
    print("please upload master_roll.csv file")
    exit()
if not os.path.exists(r"public\sample_input\responses.csv"): 
    print("please upload responses.csv file")
    exit()    
if(not os.path.exists(r"marksheets")):
    os.mkdir(r"marksheets")    
with open(r"public\sample_input\master_roll.csv", 'r') as file:
    rows = csv.reader(file)
    MR = {line[0]: [line[1], 0, 0, 0] for line in rows if line[0] != "roll"}
    m_lst=sorted(MR.keys())
with open(r"public\sample_input\responses.csv", 'r') as file:
    rows = csv.reader(file)
    Options_Name = {option[6].upper(): [element for element in option[7:]]
                    for option in rows if option[6] != 'Roll Number'}               
    try:
        i_p, i_n, Final_Score, Final_Count = float(sys.argv[1]), float(sys.argv[2]), [], []
    except:
        print("Please enter valid input")
        exit()
    for Roll, options in Options_Name.items():
        Right, Wrong, Not_Attempt = 0, 0, 0
        for i, option in enumerate(options):
            try:
              if (option == Options_Name["ANSWER"][i]):
                Right += 1
              elif(option):
                Wrong += 1
              else:
                Not_Attempt += 1  
            except:
                print("Please provide ANSWER in the responses.csv file")
                exit()
            
        Final_Count.append(f"[{Right},{Wrong},{Not_Attempt}]")
        Final_Score.append(f"{Right*i_p+Wrong*i_n}/{(Right+Wrong+Not_Attempt)*i_p}")
        try :
          MR[f"{Roll}"][1], MR[f"{Roll}"][2], MR[f"{Roll}"][3] = Right, Wrong, Not_Attempt
        except:
            pass 

for key in Options_Name:
    if (key in m_lst):m_lst.remove(key)
responses_df = pd.read_csv(r"public\sample_input\responses.csv")
no_of_columns = responses_df.shape[1]
responses_df.rename(columns={'Score': 'Google_Score'}, inplace=True)
responses_df.insert(loc=6, column='Score_After_Negative', value=Final_Score)
responses_df.insert(loc=len(responses_df.columns),column="statusAns", value=Final_Count)
for key in m_lst:
      responses_df.loc[len(responses_df.index)] =["","","ABSENT",MR[key][0],"","","ABSENT",key,"","","","","","","","","","","","","","","","","","","","","","","","","","","","",""]
responses_df.to_excel(r"marksheets\concise_marksheet.xlsx",sheet_name="concise_marksheet", index=False)
shutil.make_archive("marksheets", 'zip', "marksheets")
print("Successfully generated concise marksheet")