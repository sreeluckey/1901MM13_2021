const fs = require('fs');
const express = require('express');
const { spawnSync } = require('child_process');

if (fs.existsSync('public\\sample_input')) {
  fs.rmSync('public\\sample_input', { recursive: true ,force: true});
}
if (fs.existsSync("transcriptsIITP")) {
  fs.rmSync("transcriptsIITP", { recursive: true ,force: true});
}
fs.mkdirSync('public\\sample_input');

const app = express();

const multer = require('multer');

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public\\sample_input');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage })

const path = require('path')
app.use('/static', express.static(path.join(__dirname, 'public')))

// register view engine
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs');

var all=0, r_from ="", r_upto ="", 
message = 'Upload grades.csv,subject.csv and names_roll.csv optionally upload seal,sign then genreate all transcripts or enter ranged input to genreate required transcripts';
stmp="",sgn=""

app.get('/', (req, res) => {
  res.render('home', { message, r_from, r_upto });
});

const cpUpload = upload.fields([{ name: 'grades', maxCount: 1 },{ name: 'names_roll', maxCount: 1 },{ name: 'subject', maxCount: 1 },{ name: 'seal', maxCount: 1 }, { name: 'sign', maxCount: 1 }]);

app.post('/', cpUpload, async (req, res) => {
  console.log('line46')
  if(req.files.seal){stmp=req.files.seal[0].originalname}
  if(req.files.sign){sgn=req.files.sign[0].originalname}
  console.log('stmp',stmp)
  r_from = req.body.r_from;;    
  r_upto = req.body.r_upto;    
  if (req.body.rng) {
    all=0;
    const result = spawnSync('python', ['proj2.py', r_from,r_upto,all,stmp,sgn]);
    message = result.stdout.toString();
    error = result.stderr.toString();
    console.log(error);
    console.log(message);
  }
  if (req.body.all) {
    all=1;
    const result = spawnSync('python', ['proj2.py', r_from,r_upto,all,stmp,sgn]);
    message = result.stdout.toString();
    error = result.stderr.toString();
    console.log(error);
    console.log(message);
    };
  if (req.body.download) {
    return res.download('./transcriptsIITP.zip',);
  }
  res.redirect('/');
});


app.listen(3000, () => {
  console.log('Server started on port 3000');
});




