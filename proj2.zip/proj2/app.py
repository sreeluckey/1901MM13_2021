# run this file to start the app
# please install nodejs to run this project

#uncomment below line if fpdf not found then run this file again
#os.system("pip install fpdf")

import webbrowser
import os
path = os.path.join(os.path.dirname(__file__), 'files')
os.chdir(path)

# open the localhost:3000 in a new tab
webbrowser.open('http://localhost:3000/', new=1)
os.system('node app.js')  # run the node server
